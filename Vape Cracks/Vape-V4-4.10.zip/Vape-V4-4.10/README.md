# Vape V4

**Disclaimer:** The purpose of this project is for educational purposes only. The author does not promote any form of cheating and will not be held responsible for any consequences resulting from its use.

## Versions
- [v4.04](https://github.com/DuckySoLucky/Vape-V4/tree/v4.04)
- [v4.10](https://github.com/DuckySoLucky/Vape-V4/tree/main)


## Note
Crack supports only Vanilla and Lunar Client. Forge **DOES NOT** work since mappings are not included in the crack. If you would like to receive forge mappings feel free to contact me on the [Discord](https://discord.com/users/486155512568741900) .

## Setup
Follow these steps to set up and start the Vape v4.10:

1. Git clone this repository or download the source code as a zip file.

2. Download [Java 17.0.6](https://download.oracle.com/java/17/archive/jdk-17.0.6_windows-x64_bin.exe) or higher.

3. Launch Lunar Client.

4. Launch the `vape.bat` file.

5. Enjoy!

6. Star this repository if this helped you!